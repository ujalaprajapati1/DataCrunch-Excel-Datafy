// Global chart instances
let barChart = null;
let lineChart = null;

/**
 * Create or update charts
 * @param {Array} labels - X-axis labels
 * @param {Array} values - Y-axis values
 * @param {String} columnName - Selected column name
 */
function renderCharts(labels, values, columnName) {

    const barCtx = document.getElementById("barChart").getContext("2d");
    const lineCtx = document.getElementById("lineChart").getContext("2d");

    // Destroy old charts if they exist
    if (barChart) barChart.destroy();
    if (lineChart) lineChart.destroy();

    // Bar Chart
    barChart = new Chart(barCtx, {
        type: "bar",
        data: {
            labels: labels,
            datasets: [{
                label: columnName,
                data: values,
                backgroundColor: "#1DB954"
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    labels: { color: "#ffffff" }
                }
            },
            scales: {
                x: {
                    ticks: { color: "#b3b3b3" },
                    grid: { color: "#222222" }
                },
                y: {
                    ticks: { color: "#b3b3b3" },
                    grid: { color: "#222222" }
                }
            }
        }
    });

    // Line Chart
    lineChart = new Chart(lineCtx, {
        type: "line",
        data: {
            labels: labels,
            datasets: [{
                label: columnName,
                data: values,
                borderColor: "#1DB954",
                backgroundColor: "rgba(29,185,84,0.2)",
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    labels: { color: "#ffffff" }
                }
            },
            scales: {
                x: {
                    ticks: { color: "#b3b3b3" },
                    grid: { color: "#222222" }
                },
                y: {
                    ticks: { color: "#b3b3b3" },
                    grid: { color: "#222222" }
                }
            }
        }
    });
}

/**
 * Auto-render charts if data is injected from Flask
 * Flask will define:
 * window.chartLabels
 * window.chartValues
 * window.chartColumn
 */
document.addEventListener("DOMContentLoaded", () => {
    if (window.chartLabels && window.chartValues && window.chartColumn) {
        renderCharts(
            window.chartLabels,
            window.chartValues,
            window.chartColumn
        );
    }
});
